.. someip documentation master file, created by
   sphinx-quickstart on Sun Apr 26 08:33:38 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to someip's documentation!
==================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   someip


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
